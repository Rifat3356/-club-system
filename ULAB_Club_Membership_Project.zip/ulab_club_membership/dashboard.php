
<?php
include 'config.php';
if (!isset($_SESSION['student_id'])) { header("Location: index.php"); exit; }

$sid = $_SESSION['student_id'];
$stmt = $conn->prepare("
    SELECT m.name, m.email, m.student_id, c.name AS club_name
    FROM members m
    JOIN clubs c ON c.id = m.club_id
    WHERE m.student_id=?
");
$stmt->bind_param("s", $sid);
$stmt->execute();
$profile = $stmt->get_result()->fetch_assoc();
if (!$profile) { session_destroy(); header("Location: index.php"); exit; }
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <div>Dashboard</div>
    <nav>
        <a href="index.php">Clubs</a>
        <a style="margin-left:8px" href="logout.php">Logout</a>
    </nav>
</header>

<div class="container">
    <?php if (!empty($_SESSION['flash'])): ?>
        <div class="card" style="border-left:4px solid var(--accent)">
            <?= htmlspecialchars($_SESSION['flash']); unset($_SESSION['flash']); ?>
        </div>
    <?php endif; ?>

    <div class="card">
        <h3>Membership Details</h3>
        <p><strong>Name:</strong> <?= htmlspecialchars($profile['name']); ?></p>
        <p><strong>Student ID:</strong> <?= htmlspecialchars($profile['student_id']); ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($profile['email']); ?></p>
        <p><strong>Club:</strong> <?= htmlspecialchars($profile['club_name']); ?></p>
    </div>
</div>

<footer>© <?= date('Y'); ?> ULAB • Web Programming Lab</footer>
</body>
</html>
