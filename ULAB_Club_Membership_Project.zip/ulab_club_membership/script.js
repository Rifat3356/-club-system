
// Client-side validation with inline messages
function $(sel){ return document.querySelector(sel); }
function setMsg(id, ok, text) {
    const span = document.getElementById(id);
    span.textContent = text || "";
    span.className = "msg " + (ok ? "ok" : "err");
}

function validateStudentId(v){
    return /^[A-Za-z0-9\-]{6,20}$/.test(v);
}
function validateName(v){
    return /^[A-Za-z][A-Za-z\s'.-]{2,60}$/.test(v);
}
function validateEmail(v){
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v);
}

function attachLiveValidation(){
    const sid = $("#student_id");
    const name = $("#name");
    const email = $("#email");
    if(!sid) return;
    sid.addEventListener("input", ()=> setMsg("sid_msg", validateStudentId(sid.value), validateStudentId(sid.value) ? "Looks good." : "6–20 chars, letters/numbers/hyphen."));
    name.addEventListener("input", ()=> setMsg("name_msg", validateName(name.value), validateName(name.value) ? "Nice to meet you!" : "Min 3 letters; letters/spaces only."));
    email.addEventListener("input", ()=> setMsg("email_msg", validateEmail(email.value), validateEmail(email.value) ? "Valid email." : "Enter a valid email address."));
}

function validateForm(){
    const sid = $("#student_id").value.trim();
    const name = $("#name").value.trim();
    const email = $("#email").value.trim();
    const ok = validateStudentId(sid) && validateName(name) && validateEmail(email);
    if(!ok){
        alert("Please fix form errors before submitting.");
    }
    return ok;
}

document.addEventListener("DOMContentLoaded", attachLiveValidation);
