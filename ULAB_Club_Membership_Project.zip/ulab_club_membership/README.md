
# ULAB Club Membership – Web Programming Lab

**Stack:** HTML, CSS, JavaScript, PHP (sessions), MySQL

## Quick Start
1. Import database:
   ```sql
   SOURCE db.sql;
   ```
2. Configure DB credentials in `config.php` if needed.
3. Serve the folder from PHP server (XAMPP/Laragon/WAMP) under `htdocs`/`www`.
4. Visit `http://localhost/ulab_club_membership/index.php`.

## Features
- Browse clubs and join **one** club (enforced by UNIQUE key on `student_id`).
- Client-side validation with live feedback.
- Server-side validation, prepared statements, and CSRF token.
- PHP sessions to persist membership between pages.

## Pages
- `index.php` – list clubs
- `register.php` – join a selected club
- `save_registration.php` – handles submission
- `dashboard.php` – shows membership details
- `logout.php` – ends session

_Generated: 2025-08-30T17:40:19_
