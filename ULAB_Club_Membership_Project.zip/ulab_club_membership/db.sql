
-- ULAB Club Membership System - Database Script
-- Create database and tables
CREATE DATABASE IF NOT EXISTS ulab_club CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE ulab_club;

-- Clubs table
CREATE TABLE IF NOT EXISTS clubs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT
) ENGINE=InnoDB;

-- Members table (one club per student enforced by UNIQUE KEY)
CREATE TABLE IF NOT EXISTS members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(32) NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL,
    club_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_student (student_id),
    CONSTRAINT fk_members_club FOREIGN KEY (club_id) REFERENCES clubs(id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Seed some clubs
INSERT INTO clubs (name, description) VALUES
('Photography Club', 'For students interested in photography and visual storytelling.'),
('Debate Club', 'Sharpen critical thinking and public speaking skills.'),
('Sports Club', 'Join teams, practice, and inter-university competitions.'),
('Programming Club', 'Coding contests, workshops, and open-source projects.')
ON DUPLICATE KEY UPDATE description = VALUES(description);
