
<?php
include 'config.php';
verify_csrf();

// Basic server-side validation
$student_id = trim($_POST['student_id'] ?? '');
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$club_id = (int)($_POST['club_id'] ?? 0);

if (!preg_match('/^[A-Za-z0-9\-]{6,20}$/', $student_id)) {
    exit("Invalid student ID.");
}
if (!preg_match('/^[A-Za-z][A-Za-z\s\'.\-]{2,60}$/', $name)) {
    exit("Invalid name.");
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    exit("Invalid email.");
}

// Ensure club exists
$chk = $conn->prepare("SELECT id FROM clubs WHERE id=?");
$chk->bind_param("i", $club_id);
$chk->execute();
if (!$chk->get_result()->fetch_row()) {
    exit("Invalid club.");
}

// Insert or handle duplicate (one club per student)
try {
    $stmt = $conn->prepare("INSERT INTO members (student_id, name, email, club_id) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssi", $student_id, $name, $email, $club_id);
    $stmt->execute();
} catch (mysqli_sql_exception $e) {
    // Duplicate student_id -> fetch and set session then redirect
    if ($e->getCode() === 1062) {
        $fetch = $conn->prepare("SELECT m.name, m.email, m.club_id FROM members m WHERE m.student_id=?");
        $fetch->bind_param("s", $student_id);
        $fetch->execute();
        $existing = $fetch->get_result()->fetch_assoc();
        $_SESSION['student_id'] = $student_id;
        $_SESSION['name'] = $existing['name'];
        $_SESSION['club_id'] = (int)$existing['club_id'];
        $_SESSION['flash'] = "You are already a member. Showing your dashboard.";
        header("Location: dashboard.php");
        exit;
    } else {
        http_response_code(500);
        exit("Unable to save registration.");
    }
}

// Success -> set session and redirect
$_SESSION['student_id'] = $student_id;
$_SESSION['name'] = $name;
$_SESSION['club_id'] = $club_id;
$_SESSION['flash'] = "Registration successful!";
header("Location: dashboard.php");
exit;
?>
