
<?php include 'config.php'; ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ULAB Club Membership</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <div><strong>ULAB</strong> • Club Membership</div>
    <nav>
        <?php if(isset($_SESSION['student_id'])): ?>
            <a class="btn" href="dashboard.php">Dashboard</a>
            <a style="margin-left:8px" href="logout.php">Logout</a>
        <?php else: ?>
            <span class="chip">Guest</span>
        <?php endif; ?>
    </nav>
</header>

<div class="container">
    <h2>Available Clubs</h2>
    <p class="chip">Choose one club to join</p>
    <div class="grid">
        <?php
        $stmt = $conn->prepare("SELECT id, name, description FROM clubs ORDER BY name");
        $stmt->execute();
        $res = $stmt->get_result();
        while($row = $res->fetch_assoc()):
        ?>
        <div class="card">
            <h3><?= htmlspecialchars($row['name']); ?></h3>
            <p><?= htmlspecialchars($row['description']); ?></p>
            <a class="btn" href="register.php?club_id=<?= (int)$row['id']; ?>">Join</a>
        </div>
        <?php endwhile; ?>
    </div>
</div>

<footer>© <?= date('Y'); ?> ULAB • Web Programming Lab</footer>
</body>
</html>
