
# Open-ended Lab Report – CSE 3120 (Summer 2025)
**System:** ULAB Club Membership Registration  
**Tech:** HTML, CSS, JavaScript, PHP (sessions), MySQL

## 1) Introduction
This project implements a minimal, secure, and usable web application for online club membership at ULAB. Students can browse available clubs, register as a member of a single club, and view their membership details. The design emphasizes simplicity, security (sessions, CSRF protection, server-side validation), and data integrity (single membership per student).

## 2) Methodology
**Architecture.** The application follows a classic LAMP pattern. PHP renders views and performs DB I/O via prepared statements. Sessions store authenticated student context (`student_id`, `name`, `club_id`).  
**Database.** Two tables: `clubs` (catalog) and `members` (registrations) with a `UNIQUE(student_id)` constraint to enforce “one club per student.”  
**Validation.** Client-side JavaScript provides live feedback; server-side PHP re-validates all inputs, and a CSRF token mitigates cross-site request forgery.  
**Flow.**
1. `index.php`: fetch & display clubs.
2. `register.php`: form for the chosen club (pre-validated on client).
3. `save_registration.php`: verify CSRF, validate inputs, insert registration, set session.
4. `dashboard.php`: show membership details from a join query.
5. `logout.php`: clear session fully.

## 3) Code (key snippets)
- **Sessions & CSRF (`config.php`)** – initializes session and creates a per-session token.  
- **Prepared statements** – all DB operations use `prepare()` / `bind_param()` to avoid SQL injection.  
- **Unique membership rule** – `UNIQUE(student_id)` in `members` table with duplicate handling.

## 4) Results & Discussion
The system successfully registers a student to one club and persists their membership using sessions. The constraint prevents multi-club membership. Client-side validation reduces errors while server-side checks preserve integrity. CSRF tokens and prepared statements address common web risks.

## 5) Conclusion
The application meets the functional requirements with a compact, maintainable codebase. Future work: add e-mail verification, admin CRUD for clubs, and the option to transfer membership explicitly.

---

## Answers to Task Questions (CO1–CO3)

### Q1 (CO1): How do PHP sessions enhance security & efficiency?
- **Stateful user context:** Sessions store `student_id` and `club_id`, avoiding sensitive data in query strings and reducing repeated DB lookups on every request.  
- **Access control:** `dashboard.php` checks `$_SESSION['student_id']` to gate access.  
- **Integrity & UX:** After registration, the session conveys success state (`flash`) without persisting it to the DB.  
- **Practical example:** In `save_registration.php`, upon a successful insert, we set session variables and redirect to `dashboard.php`, which trusts that context to query joined details.

### Q2 (CO2): Why MySQL? Limitations & mitigation.
- **Why good:** Relational schema, ACID compliance, indexes, mature tooling, and broad PHP support (`mysqli`).  
- **Limitations:** Schema rigidity and horizontal scaling complexity for very large workloads.  
- **Mitigation in this project:** Kept a normalized schema, added a `UNIQUE` index for business rules, and used prepared statements for safe performance. For future scale, read replicas and caching can be introduced.

### Q3 (CO3): Ethics & citation of third‑party resources.
- **Considerations:** License compliance (MIT/Apache/GPL), avoiding uncredited code copy, and respecting data privacy.  
- **What we did:** Wrote original code, limited to standard PHP/MySQL/JS without external libraries. If libraries are later used (e.g., Bootstrap), we will cite source, version, and license in `README` and comments.

---

**Screenshots & Demo Notes** (optional): add screenshots of each page and describe any deviations.
