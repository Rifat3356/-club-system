
<?php
include 'config.php';
$club_id = isset($_GET['club_id']) ? (int)$_GET['club_id'] : 0;
$club = null;
if ($club_id > 0) {
    $stmt = $conn->prepare("SELECT id, name FROM clubs WHERE id=?");
    $stmt->bind_param("i", $club_id);
    $stmt->execute();
    $club = $stmt->get_result()->fetch_assoc();
    if (!$club) { http_response_code(404); exit("Club not found."); }
} else {
    http_response_code(400); exit("Missing club id.");
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register • <?= htmlspecialchars($club['name']); ?></title>
    <link rel="stylesheet" href="style.css">
    <script defer src="script.js"></script>
</head>
<body>
<header>
    <div><a href="index.php">← Back</a></div>
    <nav></nav>
</header>

<div class="container">
    <h2>Register for <?= htmlspecialchars($club['name']); ?></h2>
    <form action="save_registration.php" method="POST" onsubmit="return validateForm()">
        <?php csrf_field(); ?>
        <input type="hidden" name="club_id" value="<?= (int)$club['id']; ?>">

        <label for="student_id">Student ID</label>
        <input type="text" id="student_id" name="student_id" placeholder="e.g., 231014034 or ULAB-23-1034" required>
        <div id="sid_msg" class="msg"></div>

        <label for="name">Full Name</label>
        <input type="text" id="name" name="name" placeholder="Your full name" required>
        <div id="name_msg" class="msg"></div>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="you@ulab.edu.bd" required>
        <div id="email_msg" class="msg"></div>

        <div style="margin-top:14px">
            <button class="btn" type="submit">Register</button>
            <a style="margin-left:8px" href="index.php">Cancel</a>
        </div>
    </form>
</div>
</body>
</html>
